id_producto = int(input("Ingrese el identificador del producto: "))
nombre = input("Ingrese el nombre del producto: ")

# Leer los datos de  la Bd

bd_producto = open(f"Bd/{id_producto}-{nombre}.txt", "r")
id_producto = int(bd_producto.readline())
nombre = bd_producto.readline().replace("\n", "")
cantidad_por_paq = int(bd_producto.readline())
costo_galleta = int(bd_producto.readline())
costo_paq = int(bd_producto.readline())
precio_venta = int(bd_producto.readline())
stock = int(bd_producto.readline())
bd_producto.close()

# Fabricamos los procuctos

bd_movimientos = open("Bd/Movimientos.txt", "r")
saldo = int(bd_movimientos.readline())
print(f"El dinero en caja es {saldo}")
print(f"Recuerde que el costo por paquete es ${costo_paq},"
      f"por lo tanto puede fabricar máximo {saldo // costo_paq} paquetes")
cantidad_fabricar = int(input("Ingrese la cantidad de paquetes a fabricar: "))
costo_fabricacion = cantidad_fabricar * costo_paq
print(f"El costo de fabricación fue de {costo_fabricacion}")

# Acualizamos el saldo

saldo -= costo_fabricacion
print(f"Su nuevo saldo es de {saldo}")
bd_movimientos = open("Bd/Movimientos.txt", "w")
bd_movimientos.write(str(saldo))
bd_movimientos.close()

stock += cantidad_fabricar
bd_producto = open(f"Bd/{id_producto}-{nombre}.txt", "w")
bd_producto.write(f"{id_producto}\n")
bd_producto.write(f"{nombre}\n")
bd_producto.write(f"{cantidad_por_paq}\n")
bd_producto.write(f"{costo_galleta}\n")
bd_producto.write(f"{costo_paq}\n")
bd_producto.write(f"{precio_venta}\n")
bd_producto.write(f"{stock}")
bd_producto.close()
