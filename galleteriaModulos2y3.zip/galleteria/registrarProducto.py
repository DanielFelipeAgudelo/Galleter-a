# Solicitud de atributos del producto

id_producto = int(input("Ingrese el identificador del producto: "))
nombre = input("Ingrese el nombre del producto: ")
cantidad_por_paq = int(input("Ingrese la cantidad de galletas por paquete: "))
stock = 0
costo_galleta = int(input("Ingrese el costo por galleta: "))
costo_paq = costo_galleta * cantidad_por_paq
print(f"Costo por paquete: {costo_paq}")
precio_venta = int(input("Ingrese el precio del producto: "))
porc_ganancia = (precio_venta - costo_paq) / costo_paq * 100
print(f"La ganancia es del {porc_ganancia}% por paquete")

print("fin")

file = open(f"Bd/{id_producto}-{nombre}.txt", "w")

file.write(f"{id_producto}\n")
file.write(f"{nombre}\n")
file.write(f"{cantidad_por_paq}\n")
file.write(f"{costo_galleta}\n")
file.write(f"{costo_paq}\n")
file.write(f"{precio_venta}\n")
file.write(f"{stock}")

file.close()
